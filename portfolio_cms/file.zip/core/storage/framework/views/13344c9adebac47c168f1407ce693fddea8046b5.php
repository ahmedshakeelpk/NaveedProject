

<?php $__env->startSection('content'); ?>

<?php if ($__env->exists('front.partials.section-partials.home')) echo $__env->make('front.partials.section-partials.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.about')) echo $__env->make('front.partials.section-partials.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.funfact')) echo $__env->make('front.partials.section-partials.funfact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.portfolio')) echo $__env->make('front.partials.section-partials.portfolio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.testimonials')) echo $__env->make('front.partials.section-partials.testimonials', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.faq')) echo $__env->make('front.partials.section-partials.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if ($__env->exists('front.partials.section-partials.contact')) echo $__env->make('front.partials.section-partials.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveporichoy\core\resources\views/front/themes/portfolio/index.blade.php ENDPATH**/ ?>