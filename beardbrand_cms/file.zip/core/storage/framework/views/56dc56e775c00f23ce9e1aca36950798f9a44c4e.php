<footer class="main-footer">
    <div class="d-inline"><?php echo $setting->copyright_text; ?></div>
    <div class="float-right d-none d-sm-inline-block">
      <?php echo e(__('Version : 2.0')); ?>

    </div>
  </footer>
</div>
<?php /**PATH C:\laragon\www\skynet\core\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>