<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Funfact extends Model
{
    protected $guarded = [];
}
