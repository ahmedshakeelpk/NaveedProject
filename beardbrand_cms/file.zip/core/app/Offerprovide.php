<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Offerprovide extends Model
{
    protected $guarded = [];
}
