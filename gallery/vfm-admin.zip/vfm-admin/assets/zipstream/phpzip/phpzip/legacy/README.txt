If you already know how to use composer, skip this file.

Start by reading https://getcomposer.org/download/

1. download composer.phar as shown in that page.

2. from the legacy folder, run
#>php <path to composer>/composer.phar install

This will download dependencies for these test files.

